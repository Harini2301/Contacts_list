const contacts = [
  {
    name: "Example1",
    imgURL:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTFMAEPRr9VlxhQg54tAsacxdA4aJaoMZGt7q-bK1w3964lgcz8TU0KkUudov6rTZthljk&usqp=CAUhttps://wallpapers.com/images/hd/aesthetic-anime-boy-pastel-blue-sky-udbzyxaphc27yt3e.jpg",
    phone: "+123 456 789",
    email: "j@ungkook.com"
  },
  {
    name: "Example2",
    imgURL: "https://wallpapercave.com/wp/wp11011755.jpg",
    phone: "+987 654 321",
    email: "kim@namjoon.com"
  },
  {
    name: "Example3",
    imgURL: "https://avatarfiles.alphacoders.com/314/314258.jpg",
    phone: "+918 372 574",
    email: "gmail@jhope.com"
  }
];
export default contacts;
